# GitHub Deployment Instructions

Follow these steps to deploy your TypePractice website on GitHub Pages:

## 🚀 Quick Setup

### 1. Create a GitHub Repository

1. Go to [GitHub](https://github.com) and sign in
2. Click the "+" icon in the top right corner
3. Select "New repository"
4. Name your repository `typelit-clone` (or any name you prefer)
5. Make sure it's set to **Public**
6. Click "Create repository"

### 2. Upload Your Code

#### Option A: Using GitHub Web Interface

1. In your new repository, click "uploading an existing file"
2. Drag and drop all the files from your `typelit-clone` folder
3. Write a commit message like "Initial commit"
4. Click "Commit changes"

#### Option B: Using Git Commands

```bash
# Navigate to your project directory
cd /path/to/typelit-clone

# Initialize git repository
git init

# Add all files
git add .

# Commit files
git commit -m "Initial commit"

# Add your GitHub repository as origin
git remote add origin https://github.com/YOUR_USERNAME/typelit-clone.git

# Push to GitHub
git push -u origin main
```

### 3. Enable GitHub Pages

1. Go to your repository on GitHub
2. Click on "Settings" tab
3. Scroll down to "Pages" in the left sidebar
4. Under "Source", select "GitHub Actions"
5. The deployment workflow will automatically run

### 4. Access Your Website

After the GitHub Action completes (usually 2-5 minutes):
- Your website will be available at: `https://YOUR_USERNAME.github.io/typelit-clone/`

## 🔧 Configuration

### Update Repository Name

If you want to use a different repository name:

1. Update the `base` path in `vite.config.js`:
```javascript
base: process.env.NODE_ENV === 'production' ? '/YOUR_REPO_NAME/' : '/',
```

2. Update the workflow file `.github/workflows/deploy.yml` if needed

### Custom Domain (Optional)

To use a custom domain:

1. In your repository settings, go to "Pages"
2. Under "Custom domain", enter your domain name
3. Create a `CNAME` file in the `public` directory with your domain name

## 📝 Making Updates

To update your website:

1. Make changes to your code
2. Commit and push to the `main` branch:
```bash
git add .
git commit -m "Update description"
git push origin main
```
3. The GitHub Action will automatically rebuild and deploy your site

## 🛠 Troubleshooting

### Build Fails
- Check the "Actions" tab in your GitHub repository for error details
- Ensure all dependencies are properly listed in `package.json`

### 404 Errors
- Make sure the `base` path in `vite.config.js` matches your repository name
- Check that GitHub Pages is enabled and set to "GitHub Actions"

### Images Not Loading
- Ensure all images are in the `public` directory
- Check that image paths start with `/` (e.g., `/covers/book.png`)

## 📚 Adding New Books

To add new books to your library:

1. Add the book cover image to `public/covers/`
2. Add the book text file to `public/books/`
3. Update `src/components/Library.jsx` to include the new book
4. Commit and push your changes

## 🎯 Performance Tips

- Optimize images before adding them to the `public` directory
- Keep book text files reasonably sized for better loading performance
- Consider using WebP format for book covers

## 📞 Need Help?

If you encounter issues:
1. Check the GitHub Actions logs in the "Actions" tab
2. Ensure your repository is public
3. Verify that GitHub Pages is enabled
4. Check that all file paths are correct

---

**Your TypePractice website will be live and accessible to users worldwide! 🌍**

