import { useState } from 'react'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Button } from '@/components/ui/button.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Switch } from '@/components/ui/switch.jsx'
import { Slider } from '@/components/ui/slider.jsx'
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Settings, 
  Palette, 
  Type, 
  Volume2, 
  Eye, 
  Keyboard,
  Download,
  Share2,
  Trophy,
  BookOpen,
  Target,
  Zap
} from 'lucide-react'

export function AdvancedSettings({ settings, onSettingsChange }) {
  const handleSettingChange = (key, value) => {
    onSettingsChange({ ...settings, [key]: value })
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Settings className="w-5 h-5" />
          <span>Advanced Settings</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="display" className="w-full">
          <TabsList className="grid w-full grid-cols-4">
            <TabsTrigger value="display">Display</TabsTrigger>
            <TabsTrigger value="typing">Typing</TabsTrigger>
            <TabsTrigger value="audio">Audio</TabsTrigger>
            <TabsTrigger value="advanced">Advanced</TabsTrigger>
          </TabsList>
          
          <TabsContent value="display" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Show Cursor</label>
                  <p className="text-xs text-muted-foreground">Display blinking cursor at current position</p>
                </div>
                <Switch
                  checked={settings.showCursor}
                  onCheckedChange={(checked) => handleSettingChange('showCursor', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Smooth Cursor</label>
                  <p className="text-xs text-muted-foreground">Enable smooth cursor animations</p>
                </div>
                <Switch
                  checked={settings.smoothCursor}
                  onCheckedChange={(checked) => handleSettingChange('smoothCursor', checked)}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Font Size</label>
                <Slider
                  value={[settings.fontSize]}
                  onValueChange={([value]) => handleSettingChange('fontSize', value)}
                  max={24}
                  min={12}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground">{settings.fontSize}px</p>
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Lines Per Page</label>
                <Slider
                  value={[settings.linesPerPage]}
                  onValueChange={([value]) => handleSettingChange('linesPerPage', value)}
                  max={15}
                  min={5}
                  step={1}
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground">{settings.linesPerPage} lines</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="typing" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Stop on Error</label>
                  <p className="text-xs text-muted-foreground">Pause typing when an error is made</p>
                </div>
                <Switch
                  checked={settings.stopOnError}
                  onCheckedChange={(checked) => handleSettingChange('stopOnError', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Highlight Errors</label>
                  <p className="text-xs text-muted-foreground">Highlight incorrect characters</p>
                </div>
                <Switch
                  checked={settings.highlightErrors}
                  onCheckedChange={(checked) => handleSettingChange('highlightErrors', checked)}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Cursor Style</label>
                <Select
                  value={settings.cursorStyle}
                  onValueChange={(value) => handleSettingChange('cursorStyle', value)}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="block">Block</SelectItem>
                    <SelectItem value="line">Line</SelectItem>
                    <SelectItem value="underline">Underline</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="audio" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Sound Effects</label>
                  <p className="text-xs text-muted-foreground">Play sounds for keystrokes and errors</p>
                </div>
                <Switch
                  checked={settings.soundEffects}
                  onCheckedChange={(checked) => handleSettingChange('soundEffects', checked)}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Volume</label>
                <Slider
                  value={[settings.volume]}
                  onValueChange={([value]) => handleSettingChange('volume', value)}
                  max={100}
                  min={0}
                  step={5}
                  className="w-full"
                />
                <p className="text-xs text-muted-foreground">{settings.volume}%</p>
              </div>
            </div>
          </TabsContent>
          
          <TabsContent value="advanced" className="space-y-4">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Auto-save Progress</label>
                  <p className="text-xs text-muted-foreground">Automatically save typing progress</p>
                </div>
                <Switch
                  checked={settings.autoSave}
                  onCheckedChange={(checked) => handleSettingChange('autoSave', checked)}
                />
              </div>
              
              <div className="flex items-center justify-between">
                <div className="space-y-0.5">
                  <label className="text-sm font-medium">Show Statistics</label>
                  <p className="text-xs text-muted-foreground">Display detailed statistics panel</p>
                </div>
                <Switch
                  checked={settings.showStatistics}
                  onCheckedChange={(checked) => handleSettingChange('showStatistics', checked)}
                />
              </div>
              
              <div className="space-y-2">
                <label className="text-sm font-medium">Statistics Update Interval</label>
                <Select
                  value={settings.statsInterval.toString()}
                  onValueChange={(value) => handleSettingChange('statsInterval', parseInt(value))}
                >
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="100">100ms (Real-time)</SelectItem>
                    <SelectItem value="500">500ms (Smooth)</SelectItem>
                    <SelectItem value="1000">1s (Standard)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}

export function AchievementSystem({ achievements, currentStats }) {
  const achievementList = [
    {
      id: 'first_session',
      title: 'First Steps',
      description: 'Complete your first typing session',
      icon: BookOpen,
      unlocked: achievements.includes('first_session'),
      requirement: 'Complete 1 session'
    },
    {
      id: 'speed_demon',
      title: 'Speed Demon',
      description: 'Reach 60 WPM',
      icon: Zap,
      unlocked: achievements.includes('speed_demon'),
      requirement: '60+ WPM'
    },
    {
      id: 'accuracy_master',
      title: 'Accuracy Master',
      description: 'Maintain 95% accuracy for a full session',
      icon: Target,
      unlocked: achievements.includes('accuracy_master'),
      requirement: '95%+ accuracy'
    },
    {
      id: 'marathon_typist',
      title: 'Marathon Typist',
      description: 'Type for 30 minutes continuously',
      icon: Trophy,
      unlocked: achievements.includes('marathon_typist'),
      requirement: '30+ minutes'
    }
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Trophy className="w-5 h-5" />
          <span>Achievements</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {achievementList.map((achievement) => {
            const Icon = achievement.icon
            return (
              <div
                key={achievement.id}
                className={`p-4 rounded-lg border ${
                  achievement.unlocked
                    ? 'bg-green-50 border-green-200 dark:bg-green-900/20 dark:border-green-800'
                    : 'bg-muted/50 border-border'
                }`}
              >
                <div className="flex items-start space-x-3">
                  <Icon
                    className={`w-6 h-6 mt-1 ${
                      achievement.unlocked ? 'text-green-600' : 'text-muted-foreground'
                    }`}
                  />
                  <div className="flex-1">
                    <div className="flex items-center space-x-2">
                      <h4 className="font-semibold">{achievement.title}</h4>
                      {achievement.unlocked && (
                        <Badge variant="secondary" className="bg-green-100 text-green-800">
                          Unlocked
                        </Badge>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mt-1">
                      {achievement.description}
                    </p>
                    <p className="text-xs text-muted-foreground mt-2">
                      {achievement.requirement}
                    </p>
                  </div>
                </div>
              </div>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

export function ExportOptions({ onExport }) {
  const exportFormats = [
    {
      format: 'json',
      title: 'JSON Data',
      description: 'Export detailed statistics as JSON',
      icon: Download
    },
    {
      format: 'csv',
      title: 'CSV Report',
      description: 'Export session data as CSV',
      icon: Download
    },
    {
      format: 'pdf',
      title: 'PDF Report',
      description: 'Generate a comprehensive PDF report',
      icon: Download
    }
  ]

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Share2 className="w-5 h-5" />
          <span>Export & Share</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="space-y-3">
          {exportFormats.map((format) => {
            const Icon = format.icon
            return (
              <Button
                key={format.format}
                variant="outline"
                className="w-full justify-start"
                onClick={() => onExport(format.format)}
              >
                <Icon className="w-4 h-4 mr-2" />
                <div className="text-left">
                  <div className="font-medium">{format.title}</div>
                  <div className="text-xs text-muted-foreground">{format.description}</div>
                </div>
              </Button>
            )
          })}
        </div>
      </CardContent>
    </Card>
  )
}

