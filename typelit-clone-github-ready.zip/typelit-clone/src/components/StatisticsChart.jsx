import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, AreaChart, Area } from 'recharts'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { TrendingUp, Target, Clock, Zap } from 'lucide-react'

export function StatisticsChart({ data, type = 'wpm' }) {
  if (!data || data.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center space-x-2">
            <TrendingUp className="w-5 h-5" />
            <span>Performance Chart</span>
          </CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-64 flex items-center justify-center text-muted-foreground">
            Start typing to see your performance chart
          </div>
        </CardContent>
      </Card>
    )
  }

  const chartConfig = {
    wpm: {
      title: 'Words Per Minute',
      dataKey: 'wpm',
      color: '#3b82f6',
      icon: TrendingUp
    },
    accuracy: {
      title: 'Accuracy %',
      dataKey: 'accuracy',
      color: '#10b981',
      icon: Target
    },
    speed: {
      title: 'Typing Speed',
      dataKey: 'speed',
      color: '#8b5cf6',
      icon: Zap
    }
  }

  const config = chartConfig[type]
  const Icon = config.icon

  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Icon className="w-5 h-5" />
          <span>{config.title} Over Time</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="h-64">
          <ResponsiveContainer width="100%" height="100%">
            {type === 'wpm' ? (
              <AreaChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `${Math.floor(value / 60)}:${(value % 60).toString().padStart(2, '0')}`}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  labelFormatter={(value) => `Time: ${Math.floor(value / 60)}:${(value % 60).toString().padStart(2, '0')}`}
                  formatter={(value, name) => [value, name === 'wpm' ? 'WPM' : name]}
                />
                <Area
                  type="monotone"
                  dataKey={config.dataKey}
                  stroke={config.color}
                  fill={config.color}
                  fillOpacity={0.3}
                  strokeWidth={2}
                />
              </AreaChart>
            ) : (
              <LineChart data={data}>
                <CartesianGrid strokeDasharray="3 3" className="opacity-30" />
                <XAxis 
                  dataKey="time" 
                  tick={{ fontSize: 12 }}
                  tickFormatter={(value) => `${Math.floor(value / 60)}:${(value % 60).toString().padStart(2, '0')}`}
                />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip 
                  labelFormatter={(value) => `Time: ${Math.floor(value / 60)}:${(value % 60).toString().padStart(2, '0')}`}
                  formatter={(value, name) => [
                    type === 'accuracy' ? `${value}%` : value, 
                    name === 'accuracy' ? 'Accuracy' : name
                  ]}
                />
                <Line
                  type="monotone"
                  dataKey={config.dataKey}
                  stroke={config.color}
                  strokeWidth={2}
                  dot={{ fill: config.color, strokeWidth: 2, r: 4 }}
                  activeDot={{ r: 6, stroke: config.color, strokeWidth: 2 }}
                />
              </LineChart>
            )}
          </ResponsiveContainer>
        </div>
      </CardContent>
    </Card>
  )
}

export function DetailedStats({ stats }) {
  if (!stats) {
    return null
  }

  const {
    totalTime,
    totalChars,
    correctChars,
    errors,
    wpm,
    accuracy,
    consistency,
    topWpm,
    averageWpm
  } = stats

  const statItems = [
    {
      label: 'Total Time',
      value: `${Math.floor(totalTime / 60)}:${(totalTime % 60).toString().padStart(2, '0')}`,
      icon: Clock,
      color: 'text-blue-600'
    },
    {
      label: 'Characters Typed',
      value: totalChars.toLocaleString(),
      icon: TrendingUp,
      color: 'text-purple-600'
    },
    {
      label: 'Correct Characters',
      value: correctChars.toLocaleString(),
      icon: Target,
      color: 'text-green-600'
    },
    {
      label: 'Errors',
      value: errors.toLocaleString(),
      icon: Zap,
      color: 'text-red-600'
    },
    {
      label: 'Current WPM',
      value: wpm,
      icon: TrendingUp,
      color: 'text-blue-600'
    },
    {
      label: 'Average WPM',
      value: averageWpm,
      icon: TrendingUp,
      color: 'text-indigo-600'
    },
    {
      label: 'Top WPM',
      value: topWpm,
      icon: Zap,
      color: 'text-orange-600'
    },
    {
      label: 'Consistency',
      value: `${consistency}%`,
      icon: Target,
      color: 'text-teal-600'
    }
  ]

  return (
    <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
      {statItems.map((item, index) => {
        const Icon = item.icon
        return (
          <Card key={index}>
            <CardContent className="p-4">
              <div className="flex items-center space-x-2 mb-2">
                <Icon className={`w-4 h-4 ${item.color}`} />
                <span className="text-sm font-medium text-muted-foreground">{item.label}</span>
              </div>
              <div className={`text-2xl font-bold ${item.color}`}>
                {item.value}
              </div>
            </CardContent>
          </Card>
        )
      })}
    </div>
  )
}

