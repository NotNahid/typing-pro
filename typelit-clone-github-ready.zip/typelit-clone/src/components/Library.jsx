import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card.jsx";
import { Button } from "@/components/ui/button.jsx";
import { BookOpen } from "lucide-react";

const books = [
  {
    id: "pride-and-prejudice",
    title: "Pride and Prejudice",
    author: "Jane Austen",
    coverImage: "/covers/pride-and-prejudice.png",
    filePath: "/books/pride-and-prejudice.txt",
  },
  {
    id: "moby-dick",
    title: "Moby Dick",
    author: "Herman Melville",
    coverImage: "/covers/moby-dick.png",
    filePath: "/books/moby-dick.txt",
  },
  {
    id: "the-adventures-of-sherlock-holmes",
    title: "The Adventures of Sherlock Holmes",
    author: "Arthur Conan Doyle",
    coverImage: "/covers/the-adventures-of-sherlock-holmes.png",
    filePath: "/books/the-adventures-of-sherlock-holmes.txt",
  },
];

export function Library({ onSelectBook }) {
  return (
    <Card>
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <BookOpen className="w-5 h-5" />
          <span>Book Library</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-6">
          {books.map((book) => (
            <div key={book.id} className="group relative">
              <Card
                className="overflow-hidden transition-all duration-300 ease-in-out group-hover:shadow-lg group-hover:-translate-y-1"
                onClick={() => onSelectBook(book.filePath, book.title)}
              >
                <img
                  src={book.coverImage}
                  alt={`${book.title} cover`}
                  className="w-full h-auto object-cover aspect-[2/3]"
                />
                <div className="p-4">
                  <h3 className="font-semibold truncate">{book.title}</h3>
                  <p className="text-sm text-muted-foreground">{book.author}</p>
                </div>
              </Card>
              <Button
                size="sm"
                className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                onClick={() => onSelectBook(book.filePath, book.title)}
              >
                Start Typing
              </Button>
            </div>
          ))}
        </div>
      </CardContent>
    </Card>
  );
}


