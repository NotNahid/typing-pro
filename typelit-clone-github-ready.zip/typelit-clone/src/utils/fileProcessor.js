import * as pdfjsLib from 'pdfjs-dist'

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/5.4.54/pdf.worker.min.js`

/**
 * Process text content by cleaning and normalizing it
 * @param {string} text - Raw text content
 * @returns {string[]} - Array of processed lines
 */
export function processTextContent(text) {
  if (!text || typeof text !== 'string') {
    return []
  }

  // Split into lines and process each line
  const lines = text
    .split('\n')
    .map(line => {
      // Remove excessive whitespace and normalize
      return line
        .trim()
        .replace(/\s+/g, ' ') // Replace multiple spaces with single space
        .replace(/\t/g, ' ') // Replace tabs with spaces
        .replace(/\r/g, '') // Remove carriage returns
    })
    .filter(line => {
      // Filter out empty lines and lines that are too short or too long
      return line.length > 0 && line.length >= 10 && line.length <= 200
    })
    .filter(line => {
      // Filter out lines that are likely headers, footers, or page numbers
      const lowerLine = line.toLowerCase()
      
      // Skip common header/footer patterns
      if (lowerLine.match(/^(page \d+|chapter \d+|\d+\s*$)/)) return false
      if (lowerLine.match(/^(table of contents|index|bibliography)/)) return false
      if (lowerLine.match(/^(copyright|all rights reserved|isbn)/)) return false
      
      // Skip lines with mostly numbers or special characters
      const alphaCount = (line.match(/[a-zA-Z]/g) || []).length
      if (alphaCount < line.length * 0.5) return false
      
      return true
    })

  return lines
}

/**
 * Extract text from a PDF file
 * @param {File} file - PDF file object
 * @returns {Promise<string>} - Extracted text content
 */
export async function extractTextFromPDF(file) {
  try {
    const arrayBuffer = await file.arrayBuffer()
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise
    
    let fullText = ''
    const numPages = pdf.numPages
    
    // Extract text from each page
    for (let pageNum = 1; pageNum <= numPages; pageNum++) {
      try {
        const page = await pdf.getPage(pageNum)
        const textContent = await page.getTextContent()
        
        // Combine text items from the page
        const pageText = textContent.items
          .map(item => item.str)
          .join(' ')
        
        if (pageText.trim()) {
          fullText += pageText + '\n'
        }
      } catch (pageError) {
        console.warn(`Error extracting text from page ${pageNum}:`, pageError)
        // Continue with other pages
      }
    }
    
    return fullText
  } catch (error) {
    console.error('Error extracting text from PDF:', error)
    throw new Error('Failed to extract text from PDF. Please ensure the file is not encrypted or corrupted.')
  }
}

/**
 * Extract text from a TXT file
 * @param {File} file - TXT file object
 * @returns {Promise<string>} - File content as text
 */
export async function extractTextFromTXT(file) {
  try {
    const text = await file.text()
    return text
  } catch (error) {
    console.error('Error reading TXT file:', error)
    throw new Error('Failed to read text file. Please ensure the file is valid.')
  }
}

/**
 * Process uploaded file and extract text content
 * @param {File} file - Uploaded file object
 * @returns {Promise<{lines: string[], fileName: string, fileType: string}>} - Processed content
 */
export async function processUploadedFile(file) {
  if (!file) {
    throw new Error('No file provided')
  }

  const fileName = file.name
  const fileType = file.type
  let extractedText = ''

  // Validate file type
  const supportedTypes = ['text/plain', 'application/pdf']
  if (!supportedTypes.includes(fileType)) {
    throw new Error('Unsupported file type. Please upload a .txt or .pdf file.')
  }

  // Validate file size (max 10MB)
  const maxSize = 10 * 1024 * 1024 // 10MB
  if (file.size > maxSize) {
    throw new Error('File too large. Please upload a file smaller than 10MB.')
  }

  try {
    // Extract text based on file type
    if (fileType === 'application/pdf') {
      extractedText = await extractTextFromPDF(file)
    } else if (fileType === 'text/plain') {
      extractedText = await extractTextFromTXT(file)
    }

    // Process the extracted text
    const lines = processTextContent(extractedText)

    if (lines.length === 0) {
      throw new Error('No readable text found in the file. Please ensure the file contains text content.')
    }

    if (lines.length < 5) {
      throw new Error('File contains too little text for a meaningful typing practice session.')
    }

    return {
      lines,
      fileName,
      fileType,
      totalLines: lines.length,
      estimatedWords: lines.join(' ').split(' ').length
    }
  } catch (error) {
    if (error.message.includes('Failed to')) {
      throw error
    }
    throw new Error(`Error processing file: ${error.message}`)
  }
}

/**
 * Generate sample text for demonstration
 * @returns {string[]} - Array of sample lines
 */
export function generateSampleText() {
  const sampleText = `
Welcome to TypePractice, the free alternative to expensive typing practice platforms.

This is a sample text to demonstrate the typing practice functionality. You can upload your own PDF or TXT files to practice with any content you want.

Unlike other platforms that charge monthly fees for file uploads, TypePractice offers this feature completely free. You can practice typing with books, articles, documents, or any text content you prefer.

The application tracks your words per minute, accuracy, and provides real-time feedback as you type. You can see your progress with visual indicators for correct and incorrect characters.

Features include dark mode support, pagination for long documents, pause and resume functionality, and comprehensive statistics tracking.

Start by uploading a file using the upload button in the header, or continue practicing with this sample text.

Remember to maintain good posture while typing and take breaks to avoid strain. Happy typing!
  `

  return processTextContent(sampleText)
}

/**
 * Validate text content for typing practice
 * @param {string[]} lines - Array of text lines
 * @returns {boolean} - Whether the content is suitable for typing practice
 */
export function validateTextContent(lines) {
  if (!Array.isArray(lines) || lines.length === 0) {
    return false
  }

  // Check minimum content requirements
  if (lines.length < 3) {
    return false
  }

  // Check average line length
  const totalChars = lines.join('').length
  const avgLineLength = totalChars / lines.length
  
  if (avgLineLength < 20 || avgLineLength > 150) {
    return false
  }

  return true
}

/**
 * Get file statistics
 * @param {string[]} lines - Array of text lines
 * @returns {object} - File statistics
 */
export function getFileStatistics(lines) {
  if (!Array.isArray(lines) || lines.length === 0) {
    return {
      totalLines: 0,
      totalCharacters: 0,
      totalWords: 0,
      averageLineLength: 0,
      estimatedTypingTime: 0
    }
  }

  const totalCharacters = lines.join('').length
  const totalWords = lines.join(' ').split(/\s+/).filter(word => word.length > 0).length
  const averageLineLength = Math.round(totalCharacters / lines.length)
  
  // Estimate typing time based on 40 WPM average
  const estimatedTypingTime = Math.round(totalWords / 40) // minutes

  return {
    totalLines: lines.length,
    totalCharacters,
    totalWords,
    averageLineLength,
    estimatedTypingTime
  }
}

