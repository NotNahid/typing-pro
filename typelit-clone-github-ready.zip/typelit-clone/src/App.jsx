import { useState, useEffect, useRef, useCallback } from 'react'
import { Button } from '@/components/ui/button.jsx'
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card.jsx'
import { Progress } from '@/components/ui/progress.jsx'
import { Badge } from '@/components/ui/badge.jsx'
import { Separator } from '@/components/ui/separator.jsx'
import { Alert, AlertDescription } from '@/components/ui/alert.jsx'
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs.jsx'
import { 
  Upload, 
  RotateCcw, 
  Moon, 
  Sun, 
  ChevronLeft, 
  ChevronRight, 
  Play, 
  Pause,
  FileText,
  BookOpen,
  Timer,
  Target,
  TrendingUp,
  Settings,
  Download,
  AlertCircle,
  CheckCircle,
  Info,
  BarChart3,
  Trophy
} from 'lucide-react'
import { processUploadedFile, generateSampleText, getFileStatistics } from './utils/fileProcessor.js'
import { StatisticsChart, DetailedStats } from './components/StatisticsChart.jsx'
import { AdvancedSettings, AchievementSystem, ExportOptions } from './components/AdvancedFeatures.jsx'
import { Library } from './components/Library.jsx'
import './App.css'

function App() {
  // Core state
  const [text, setText] = useState('')
  const [lines, setLines] = useState([])
  const [currentLine, setCurrentLine] = useState(0)
  const [currentChar, setCurrentChar] = useState(0)
  const [typedText, setTypedText] = useState('')
  const [isActive, setIsActive] = useState(false)
  const [isCompleted, setIsCompleted] = useState(false)
  
  // UI state
  const [isDark, setIsDark] = useState(false)
  const [currentPage, setCurrentPage] = useState(0)
  const [fileName, setFileName] = useState('')
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState('')
  const [fileStats, setFileStats] = useState(null)
  
  // Statistics
  const [startTime, setStartTime] = useState(null)
  const [elapsedTime, setElapsedTime] = useState(0)
  const [wpm, setWpm] = useState(0)
  const [accuracy, setAccuracy] = useState(100)
  const [totalChars, setTotalChars] = useState(0)
  const [correctChars, setCorrectChars] = useState(0)
  const [errors, setErrors] = useState(0)
  const [performanceData, setPerformanceData] = useState([])
  const [sessionStats, setSessionStats] = useState(null)
  const [achievements, setAchievements] = useState([])
  
  // Settings
  const [settings, setSettings] = useState({
    showCursor: true,
    smoothCursor: true,
    fontSize: 18,
    linesPerPage: 8,
    stopOnError: false,
    highlightErrors: true,
    cursorStyle: 'block',
    soundEffects: false,
    volume: 50,
    autoSave: true,
    showStatistics: true,
    statsInterval: 1000
  })
  
  // Configuration
  const linesPerPage = settings.linesPerPage
  const fileInputRef = useRef(null)
  const hiddenInputRef = useRef(null)

  // Performance tracking
  const updatePerformanceData = useCallback(() => {
    if (isActive && startTime) {
      const currentTime = Math.floor((Date.now() - startTime) / 1000)
      const currentWpm = elapsedTime > 0 ? Math.round((correctChars / 5) / (elapsedTime / 60)) : 0
      const currentAccuracy = totalChars > 0 ? Math.round((correctChars / totalChars) * 100) : 100
      
      setPerformanceData(prev => [...prev, {
        time: currentTime,
        wpm: currentWpm,
        accuracy: currentAccuracy,
        speed: currentWpm
      }])
    }
  }, [isActive, startTime, elapsedTime, correctChars, totalChars])

  // Achievement checking
  const checkAchievements = useCallback(() => {
    const newAchievements = [...achievements]
    
    // First session
    if (isCompleted && !achievements.includes('first_session')) {
      newAchievements.push('first_session')
    }
    
    // Speed demon (60+ WPM)
    if (wpm >= 60 && !achievements.includes('speed_demon')) {
      newAchievements.push('speed_demon')
    }
    
    // Accuracy master (95%+ accuracy)
    if (accuracy >= 95 && isCompleted && !achievements.includes('accuracy_master')) {
      newAchievements.push('accuracy_master')
    }
    
    // Marathon typist (30+ minutes)
    if (elapsedTime >= 1800 && !achievements.includes('marathon_typist')) {
      newAchievements.push('marathon_typist')
    }
    
    if (newAchievements.length > achievements.length) {
      setAchievements(newAchievements)
    }
  }, [achievements, isCompleted, wpm, accuracy, elapsedTime])

  // Initialize with sample text
  useEffect(() => {
    const sampleLines = generateSampleText()
    setLines(sampleLines)
    setFileName('Sample Text')
    setFileStats(getFileStatistics(sampleLines))
  }, [])
  
  // Timer effect
  useEffect(() => {
    let interval = null
    if (isActive && startTime) {
      interval = setInterval(() => {
        const now = Date.now()
        const elapsed = Math.floor((now - startTime) / 1000)
        setElapsedTime(elapsed)
        
        // Calculate WPM (words per minute)
        const minutes = elapsed / 60
        const wordsTyped = correctChars / 5 // Standard: 5 chars = 1 word
        const currentWpm = minutes > 0 ? Math.round(wordsTyped / minutes) : 0
        setWpm(currentWpm)
        
        // Calculate accuracy
        const currentAccuracy = totalChars > 0 ? Math.round((correctChars / totalChars) * 100) : 100
        setAccuracy(currentAccuracy)
        
        // Update performance data every few seconds
        if (elapsed % 5 === 0) {
          updatePerformanceData()
        }
        
        // Check achievements
        checkAchievements()
      }, settings.statsInterval)
    }
    return () => clearInterval(interval)
  }, [isActive, startTime, correctChars, totalChars, settings.statsInterval, updatePerformanceData, checkAchievements])

  // Dark mode effect
  useEffect(() => {
    if (isDark) {
      document.documentElement.classList.add('dark')
    } else {
      document.documentElement.classList.remove('dark')
    }
  }, [isDark])

  // Focus management
  useEffect(() => {
    if (isActive && hiddenInputRef.current) {
      hiddenInputRef.current.focus()
    }
  }, [isActive, currentLine])

  // File processing functions
  const processText = useCallback((processedLines, name, stats) => {
    setLines(processedLines)
    setFileName(name)
    setFileStats(stats)
    setCurrentLine(0)
    setCurrentChar(0)
    setCurrentPage(0)
    setTypedText('')
    setIsActive(false)
    setIsCompleted(false)
    setError('')
    resetStats()
  }, [])

  const handleFileUpload = useCallback(async (event) => {
    const file = event.target.files[0]
    if (!file) return

    setIsLoading(true)
    setError('')
    
    try {
      const result = await processUploadedFile(file)
      processText(result.lines, result.fileName, getFileStatistics(result.lines))
    } catch (error) {
      console.error('Error processing file:', error)
      setError(error.message)
    } finally {
      setIsLoading(false)
    }
    
    // Reset file input
    event.target.value = ''
  }, [processText])

  // Typing logic
  const handleTyping = useCallback((event) => {
    if (!isActive || isCompleted || lines.length === 0) return
    
    const value = event.target.value
    const currentLineText = lines[currentLine] || ''
    
    // Start timer on first keystroke
    if (!startTime) {
      setStartTime(Date.now())
    }
    
    // Handle line completion
    if (value.endsWith("\n") || (value.length === currentLineText.length && value === currentLineText)) {
      const lineToCheck = value.endsWith("\n") ? value.slice(0, -1) : value
      
      // Update statistics for the completed line
      for (let i = 0; i < currentLineText.length; i++) {
        setTotalChars(prev => prev + 1)
        if (i < lineToCheck.length && lineToCheck[i] === currentLineText[i]) {
          setCorrectChars(prev => prev + 1)
        } else {
          setErrors(prev => prev + 1)
        }
      }
      
      // Move to next line
      const nextLine = currentLine + 1
      if (nextLine >= lines.length) {
        // Test completed
        setIsCompleted(true)
        setIsActive(false)
        return
      }
      
      setCurrentLine(nextLine)
      setCurrentChar(0)
      setTypedText("")
      event.target.value = ""
      
      // Auto-navigate to next page if needed
      const newPage = Math.floor(nextLine / linesPerPage)
      if (newPage !== currentPage) {
        setCurrentPage(newPage)
      }
      
      return
    }
    
    // Update current typing
    setTypedText(value)
    setCurrentChar(value.length)
    
    // Update real-time statistics
    if (value.length > 0) {
      const lastChar = value[value.length - 1]
      const expectedChar = currentLineText[value.length - 1]
      
      setTotalChars(prev => prev + 1)
      if (lastChar === expectedChar) {
        setCorrectChars(prev => prev + 1)
      } else {
        setErrors(prev => prev + 1)
      }
    }
  }, [isActive, isCompleted, lines, currentLine, startTime, currentPage, linesPerPage])

  // Function to handle double click to start from anywhere
  const handleLineDoubleClick = useCallback((lineIndex) => {
    if (!isActive && !isCompleted) {
      setCurrentLine(lineIndex)
      setCurrentChar(0)
      setTypedText("")
      setIsActive(true)
      setStartTime(Date.now())
      if (hiddenInputRef.current) {
        hiddenInputRef.current.focus()
      }
    }
  }, [isActive, isCompleted])

  // Control functions
  const startTest = useCallback(() => {
    if (lines.length === 0) return
    setIsActive(true)
    setStartTime(Date.now())
    if (hiddenInputRef.current) {
      hiddenInputRef.current.focus()
    }
  }, [lines.length])

  const pauseTest = useCallback(() => {
    setIsActive(false)
  }, [])

  const resetStats = useCallback(() => {
    setStartTime(null)
    setElapsedTime(0)
    setWpm(0)
    setAccuracy(100)
    setTotalChars(0)
    setCorrectChars(0)
    setErrors(0)
    setPerformanceData([])
  }, [])

  const resetTest = useCallback(() => {
    setCurrentLine(0)
    setCurrentChar(0)
    setCurrentPage(0)
    setTypedText('')
    setIsActive(false)
    setIsCompleted(false)
    resetStats()
    if (hiddenInputRef.current) {
      hiddenInputRef.current.value = ''
    }
  }, [resetStats])

  // Export functionality
  const handleExport = useCallback((format) => {
    const exportData = {
      session: {
        fileName,
        totalTime: elapsedTime,
        totalChars,
        correctChars,
        errors,
        wpm,
        accuracy,
        linesCompleted: currentLine,
        totalLines: lines.length
      },
      performanceData,
      achievements,
      timestamp: new Date().toISOString()
    }

    if (format === 'json') {
      const blob = new Blob([JSON.stringify(exportData, null, 2)], { type: 'application/json' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `typing-session-${new Date().toISOString().split('T')[0]}.json`
      a.click()
      URL.revokeObjectURL(url)
    } else if (format === 'csv') {
      const csvData = performanceData.map(row => 
        `${row.time},${row.wpm},${row.accuracy}`
      ).join('\n')
      const csvContent = 'Time,WPM,Accuracy\n' + csvData
      const blob = new Blob([csvContent], { type: 'text/csv' })
      const url = URL.createObjectURL(blob)
      const a = document.createElement('a')
      a.href = url
      a.download = `typing-performance-${new Date().toISOString().split('T')[0]}.csv`
      a.click()
      URL.revokeObjectURL(url)
    }
  }, [fileName, elapsedTime, totalChars, correctChars, errors, wpm, accuracy, currentLine, lines.length, performanceData, achievements])

  // Handle library book selection
  const handleSelectBook = useCallback(async (filePath, bookTitle) => {
    setIsLoading(true)
    setError('')
    
    try {
      const response = await fetch(filePath)
      if (!response.ok) {
        throw new Error('Failed to load book')
      }
      const text = await response.text()
      const bookLines = text.split('\n').filter(line => line.trim() !== '')
      
      processText(bookLines, bookTitle, getFileStatistics(bookLines))
    } catch (error) {
      console.error('Error loading book:', error)
      setError('Failed to load the selected book. Please try again.')
    } finally {
      setIsLoading(false)
    }
  }, [processText])

  // Calculate detailed session stats
  useEffect(() => {
    if (performanceData.length > 0) {
      const wpmValues = performanceData.map(d => d.wpm).filter(w => w > 0)
      const topWpm = Math.max(...wpmValues, 0)
      const averageWpm = wpmValues.length > 0 ? Math.round(wpmValues.reduce((a, b) => a + b, 0) / wpmValues.length) : 0
      
      // Calculate consistency (how close values are to average)
      const variance = wpmValues.length > 1 ? 
        wpmValues.reduce((acc, val) => acc + Math.pow(val - averageWpm, 2), 0) / wpmValues.length : 0
      const consistency = Math.max(0, Math.round(100 - Math.sqrt(variance)))

      setSessionStats({
        totalTime: elapsedTime,
        totalChars,
        correctChars,
        errors,
        wpm,
        accuracy,
        topWpm,
        averageWpm,
        consistency
      })
    }
  }, [performanceData, elapsedTime, totalChars, correctChars, errors, wpm, accuracy])

  // Navigation
  const goToPage = useCallback((page) => {
    const maxPage = Math.ceil(lines.length / linesPerPage) - 1
    const newPage = Math.max(0, Math.min(page, maxPage))
    setCurrentPage(newPage)
  }, [lines.length, linesPerPage])

  // Render functions
  const renderTypingArea = useCallback(() => {
    const startIndex = currentPage * linesPerPage
    const endIndex = Math.min(startIndex + linesPerPage, lines.length)
    const currentLines = lines.slice(startIndex, endIndex)

    return (
      <div className="relative font-mono text-lg leading-relaxed">
        {currentLines.map((line, lineIndex) => {
          const absoluteLineIndex = startIndex + lineIndex
          const isCurrentLine = absoluteLineIndex === currentLine
          const isLineCompleted = absoluteLineIndex < currentLine

          return (
            <p
              key={absoluteLineIndex}
              className={`whitespace-pre-wrap ${isLineCompleted ? 'text-muted-foreground' : ''}`}
              onDoubleClick={() => handleLineDoubleClick(absoluteLineIndex)}
            >
              {line.split('').map((char, charIndex) => {
                const isCurrentChar = isCurrentLine && charIndex === currentChar
                const isTyped = isCurrentLine && charIndex < currentChar
                const typedChar = typedText[charIndex]
                const isCorrect = typedChar === char
                const isError = isTyped && !isCorrect

                let charClass = ''
                if (isLineCompleted) {
                  charClass = 'text-muted-foreground'
                } else if (isCurrentLine) {
                  if (isCurrentChar && settings.showCursor) {
                    charClass = `relative z-10 ${settings.cursorStyle === 'block' ? 'bg-primary text-primary-foreground' : 'border-b-2 border-primary'} ${settings.smoothCursor ? 'transition-all duration-100 ease-linear' : ''}`
                  } else if (isTyped) {
                    if (isError) {
                      charClass = settings.highlightErrors ? 'text-red-500' : 'text-green-500'
                    } else {
                      charClass = 'text-green-500'
                    }
                  }
                }

                return (
                  <span key={charIndex} className={charClass}>
                    {isCurrentChar && settings.cursorStyle === 'line' ? <span className="border-l-2 border-primary animate-pulse">{char}</span> : char}
                  </span>
                )
              })}
            </p>
          )
        })}
        {isActive && settings.showCursor && settings.cursorStyle === 'block' && (
          <span
            className="absolute bg-primary text-primary-foreground animate-pulse"
            style={{
              left: `calc(${currentChar}ch + ${settings.fontSize / 4}px)`,
              top: `calc(${(currentLine % linesPerPage) * settings.fontSize * 1.5}px + ${settings.fontSize / 4}px)`,
              width: `${settings.fontSize}px`,
              height: `${settings.fontSize * 1.5}px`,
            }}
          />
        )}
      </div>
    )
  }, [currentLine, currentChar, typedText, lines, currentPage, linesPerPage, settings, handleLineDoubleClick])

  const formatTime = (seconds) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const totalPages = Math.ceil(lines.length / linesPerPage)
  const progress = lines.length > 0 ? (currentLine / lines.length) * 100 : 0

  return (
    <div className="min-h-screen bg-background">
      {/* Header */}
      <header className="border-b bg-card">
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <BookOpen className="w-8 h-8 text-primary" />
              <h1 className="text-2xl font-bold">TypePractice</h1>
              <Badge variant="secondary">Free Forever</Badge>
            </div>
            
            <div className="flex items-center space-x-2">
              <input
                ref={fileInputRef}
                type="file"
                accept=".txt,.pdf"
                onChange={handleFileUpload}
                className="hidden"
              />
              <Button
                onClick={() => fileInputRef.current?.click()}
                variant="default"
                className="flex items-center space-x-2"
                disabled={isLoading}
              >
                <Upload className="w-4 h-4" />
                <span>{isLoading ? 'Processing...' : 'Upload File'}</span>
              </Button>
              
              <Button
                onClick={() => setIsDark(!isDark)}
                variant="outline"
                size="icon"
              >
                {isDark ? <Sun className="w-4 h-4" /> : <Moon className="w-4 h-4" />}
              </Button>
            </div>
          </div>

          {/* Stats Row */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mb-4">
            <Card>
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center space-x-2 mb-1">
                  <TrendingUp className="w-4 h-4 text-primary" />
                  <span className="text-sm font-medium">WPM</span>
                </div>
                <div className="text-2xl font-bold text-primary">{wpm}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center space-x-2 mb-1">
                  <Target className="w-4 h-4 text-green-600" />
                  <span className="text-sm font-medium">Accuracy</span>
                </div>
                <div className="text-2xl font-bold text-green-600">{accuracy}%</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center space-x-2 mb-1">
                  <Timer className="w-4 h-4 text-blue-600" />
                  <span className="text-sm font-medium">Time</span>
                </div>
                <div className="text-2xl font-bold text-blue-600">{formatTime(elapsedTime)}</div>
              </CardContent>
            </Card>
            
            <Card>
              <CardContent className="p-3 text-center">
                <div className="flex items-center justify-center space-x-2 mb-1">
                  <FileText className="w-4 h-4 text-purple-600" />
                  <span className="text-sm font-medium">Progress</span>
                </div>
                <div className="text-2xl font-bold text-purple-600">{currentLine}/{lines.length}</div>
              </CardContent>
            </Card>
          </div>

          {/* Error Display */}
          {error && (
            <Alert variant="destructive" className="mb-4">
              <AlertCircle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {/* File Statistics */}
          {fileStats && (
            <Alert className="mb-4">
              <Info className="h-4 w-4" />
              <AlertDescription>
                <strong>{fileName}</strong> - {fileStats.totalLines} lines, {fileStats.totalWords} words, 
                estimated {fileStats.estimatedTypingTime} minutes at 40 WPM
              </AlertDescription>
            </Alert>
          )}

          {/* Controls */}
          {lines.length > 0 && (
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-2">
                {!isActive && !isCompleted && (
                  <Button onClick={startTest} className="flex items-center space-x-2">
                    <Play className="w-4 h-4" />
                    <span>Start</span>
                  </Button>
                )}
                
                {isActive && (
                  <Button onClick={pauseTest} variant="outline" className="flex items-center space-x-2">
                    <Pause className="w-4 h-4" />
                    <span>Pause</span>
                  </Button>
                )}
                
                <Button onClick={resetTest} variant="outline" className="flex items-center space-x-2">
                  <RotateCcw className="w-4 h-4" />
                  <span>Reset</span>
                </Button>
              </div>

              {/* Pagination */}
              {totalPages > 1 && (
                <div className="flex items-center space-x-2">
                  <Button
                    onClick={() => goToPage(currentPage - 1)}
                    disabled={currentPage === 0}
                    variant="outline"
                    size="sm"
                  >
                    <ChevronLeft className="w-4 h-4" />
                  </Button>
                  
                  <span className="text-sm text-muted-foreground">
                    Page {currentPage + 1} of {totalPages}
                  </span>
                  
                  <Button
                    onClick={() => goToPage(currentPage + 1)}
                    disabled={currentPage >= totalPages - 1}
                    variant="outline"
                    size="sm"
                  >
                    <ChevronRight className="w-4 h-4" />
                  </Button>
                </div>
              )}
            </div>
          )}

          {/* Progress Bar */}
          {lines.length > 0 && (
            <div className="mt-4">
              <Progress value={progress} className="h-2" />
            </div>
          )}
        </div>
      </header>

      {/* Main Content */}
      <main className="container mx-auto px-4 py-8">
        <Tabs defaultValue="practice" className="w-full">
          <TabsList className="grid w-full grid-cols-5">
            <TabsTrigger value="practice">Practice</TabsTrigger>
            <TabsTrigger value="library">Library</TabsTrigger>
            <TabsTrigger value="statistics">Statistics</TabsTrigger>
            <TabsTrigger value="settings">Settings</TabsTrigger>
            <TabsTrigger value="achievements">Achievements</TabsTrigger>
          </TabsList>
          
          <TabsContent value="practice" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle className="flex items-center justify-between">
                  <span>
                    {fileName ? `Typing: ${fileName}` : 'Typing Practice'}
                  </span>
                  {isCompleted && (
                    <Badge variant="default" className="bg-green-600">
                      Completed!
                    </Badge>
                  )}
                </CardTitle>
              </CardHeader>
              <CardContent>
                {isCompleted ? (
                  <div className="text-center py-12">
                    <div className="text-6xl mb-4">🎉</div>
                    <h2 className="text-3xl font-bold mb-4">Congratulations!</h2>
                    <p className="text-lg text-muted-foreground mb-6">
                      You've completed the typing test!
                    </p>
                    <div className="grid grid-cols-2 md:grid-cols-4 gap-4 max-w-2xl mx-auto mb-6">
                      <div className="text-center">
                        <div className="text-2xl font-bold text-primary">{wpm}</div>
                        <div className="text-sm text-muted-foreground">WPM</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-green-600">{accuracy}%</div>
                        <div className="text-sm text-muted-foreground">Accuracy</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-blue-600">{formatTime(elapsedTime)}</div>
                        <div className="text-sm text-muted-foreground">Time</div>
                      </div>
                      <div className="text-center">
                        <div className="text-2xl font-bold text-red-600">{errors}</div>
                        <div className="text-sm text-muted-foreground">Errors</div>
                      </div>
                    </div>
                    <Button onClick={resetTest} className="flex items-center space-x-2">
                      <RotateCcw className="w-4 h-4" />
                      <span>Try Again</span>
                    </Button>
                  </div>
                ) : (
                  <div className="min-h-96" style={{ fontSize: `${settings.fontSize}px` }}>
                    {renderTypingArea()}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>
          
          <TabsContent value="library" className="space-y-6">
            <Library onSelectBook={handleSelectBook} />
          </TabsContent>
          
          <TabsContent value="statistics" className="space-y-6">
            {sessionStats && <DetailedStats stats={sessionStats} />}
            
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              <StatisticsChart data={performanceData} type="wpm" />
              <StatisticsChart data={performanceData} type="accuracy" />
            </div>
            
            <ExportOptions onExport={handleExport} />
          </TabsContent>
          
          <TabsContent value="settings" className="space-y-6">
            <AdvancedSettings 
              settings={settings} 
              onSettingsChange={setSettings} 
            />
          </TabsContent>
          
          <TabsContent value="achievements" className="space-y-6">
            <AchievementSystem 
              achievements={achievements} 
              currentStats={sessionStats} 
            />
          </TabsContent>
        </Tabs>

        {/* Hidden input for capturing keystrokes */}
        <input
          ref={hiddenInputRef}
          type="text"
          onChange={handleTyping}
          className="absolute opacity-0 pointer-events-none -z-10"
          autoComplete="off"
          autoCorrect="off"
          autoCapitalize="off"
          spellCheck="false"
        />
      </main>

      {/* Footer */}
      <footer className="border-t bg-card mt-12">
        <div className="container mx-auto px-4 py-6">
          <div className="text-center text-muted-foreground">
            <p className="mb-2">
              <strong>TypePractice</strong> - Free typing practice with your own files
            </p>
            <p className="text-sm">
              Upload PDF and TXT files for free - no subscription required!
            </p>
          </div>
        </div>
      </footer>
    </div>
  )
}

export default App

