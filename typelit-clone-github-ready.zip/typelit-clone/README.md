# TypePractice - Free Typing Practice Website

A comprehensive typing practice website similar to TypeLit.io, but with **FREE file uploads** and advanced features. Built with React, TypeScript, and modern web technologies.

## 🌟 Features

### Core Functionality
- ✅ **Free PDF & TXT file uploads** (TypeLit.io charges $5/month for this!)
- ✅ Real-time typing practice with visual feedback
- ✅ Accurate WPM and accuracy tracking
- ✅ Progress tracking with completion percentage
- ✅ Pagination for long documents
- ✅ Pause/resume functionality
- ✅ **Start from anywhere** - Double-click any line to begin typing from that point

### Advanced Features
- 📊 **Detailed Statistics Dashboard** with performance charts
- 🏆 **Achievement System** with unlockable badges
- ⚙️ **Comprehensive Settings** (font size, cursor style, audio, etc.)
- 🌙 **Dark/Light Mode** toggle
- 📈 **Performance Charts** showing WPM and accuracy over time
- 💾 **Export Options** (JSON, CSV data export)
- 📚 **Book Library** with classic literature
- 📱 **Responsive Design** for mobile and desktop

### Professional PDF Processing
- 🔧 Advanced PDF text extraction using PDF.js
- 🧹 Smart text cleaning and formatting
- 📄 Support for multi-page documents
- ⚡ Efficient file processing with error handling

## 🚀 Live Demo

Visit the live website: [TypePractice](https://your-github-username.github.io/typelit-clone)

## 💰 Competitive Advantage

- **TypeLit.io charges $5/month** for file uploads
- **TypePractice offers this for FREE** - major competitive advantage!
- More advanced features than the original TypeLit.io
- Modern, professional interface with better UX

## 🛠 Tech Stack

- **Frontend**: React 18 + Vite
- **Styling**: Tailwind CSS + shadcn/ui components
- **Charts**: Recharts for data visualizations
- **PDF Processing**: PDF.js for robust text extraction
- **Icons**: Lucide React
- **Deployment**: GitHub Pages

## 📦 Installation

1. Clone the repository:
```bash
git clone https://github.com/your-username/typelit-clone.git
cd typelit-clone
```

2. Install dependencies:
```bash
npm install
# or
pnpm install
```

3. Start the development server:
```bash
npm run dev
# or
pnpm run dev
```

4. Open [http://localhost:5173](http://localhost:5173) in your browser.

## 🏗 Building for Production

```bash
npm run build
# or
pnpm run build
```

The built files will be in the `dist` directory.

## 📚 Adding New Books to Library

To add new books to the library:

1. Add book cover image to `public/covers/` directory
2. Add book text file to `public/books/` directory
3. Update the `books` array in `src/components/Library.jsx`:

```javascript
{
  id: "your-book-id",
  title: "Your Book Title",
  author: "Author Name",
  coverImage: "/covers/your-book-cover.png",
  filePath: "/books/your-book.txt",
}
```

## 🎯 Usage

1. **Upload Files**: Click the "Upload File" button to upload your own PDF or TXT files
2. **Library**: Browse the pre-loaded classic books in the Library tab
3. **Practice**: Start typing and see real-time feedback
4. **Start Anywhere**: Double-click any line to begin typing from that position
5. **Statistics**: View detailed performance analytics
6. **Settings**: Customize your typing experience
7. **Achievements**: Unlock badges as you improve

## 🤝 Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the project
2. Create your feature branch (`git checkout -b feature/AmazingFeature`)
3. Commit your changes (`git commit -m 'Add some AmazingFeature'`)
4. Push to the branch (`git push origin feature/AmazingFeature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Inspired by TypeLit.io
- Built with modern React ecosystem
- Uses public domain books from Project Gutenberg
- Icons by Lucide
- UI components by shadcn/ui

## 📞 Support

If you have any questions or need help, please open an issue on GitHub.

---

**Made with ❤️ for the typing community**

